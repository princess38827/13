import { callMuse } from './museClient.js';
import { SPECIALISTS } from './agents.js';

const ROSTER_TEXT = SPECIALISTS.map((s) => `- ${s.id}: ${s.blurb}`).join('\n');

const ROUTER_TRIAGE_PROMPT = `You are the Router agent, coordinator of a 13-agent AI cluster called Cluster. Read the user's message and decide which specialists should weigh in.

Specialists available:
${ROSTER_TEXT}

Reply with ONLY a JSON object, no other text, in exactly this shape:
{"consult": ["id1", "id2"], "reason": "one short sentence"}

Pick 1 to 4 specialists whose expertise is genuinely relevant. For simple small talk, one specialist — or an empty list — is fine.`;

const ROUTER_SYNTH_PROMPT = `You are the Router agent, now writing the single final reply on behalf of the whole Cluster. You've been given notes from the specialists you consulted. Write ONE natural, well-organized reply in your own voice, as a single helpful assistant speaking directly to the user. Weave in useful points from the notes. Never mention the specialists, agents, or that a cluster is involved — just answer well.`;

function formatHistory(history) {
  if (!Array.isArray(history) || history.length === 0) return '';
  return history
    .slice(-6)
    .map((h) => `${h.role === 'user' ? 'User' : 'Assistant'}: ${h.content}`)
    .join('\n');
}

function withContext(message, history) {
  const hist = formatHistory(history);
  return hist ? `Recent conversation:\n${hist}\n\nCurrent message: ${message}` : `Current message: ${message}`;
}

function parseRouterJSON(raw) {
  try {
    const match = raw.match(/\{[\s\S]*\}/);
    const parsed = JSON.parse(match ? match[0] : raw);
    const validIds = new Set(SPECIALISTS.map((s) => s.id));
    const ids = Array.isArray(parsed.consult) ? parsed.consult.filter((id) => validIds.has(id)) : [];
    return { consult: ids.slice(0, 4), reason: parsed.reason || '' };
  } catch {
    // Lenient fallback if the model didn't return clean JSON.
    return { consult: ['researcher', 'writer'], reason: 'fallback: used a default pair' };
  }
}

export async function routeMessage(message) {
  const raw = await callMuse({
    systemPrompt: ROUTER_TRIAGE_PROMPT,
    userMessage: `Current message: ${message}`,
    reasoningEffort: 'low',
    maxTokens: 150
  });
  return parseRouterJSON(raw);
}

export async function consultSpecialists(ids, message, history) {
  const chosen = SPECIALISTS.filter((s) => ids.includes(s.id));
  const context = withContext(message, history);

  const results = await Promise.all(
    chosen.map(async (s) => {
      try {
        const content = await callMuse({
          systemPrompt: s.systemPrompt,
          userMessage: context,
          reasoningEffort: 'medium',
          maxTokens: 300
        });
        return { id: s.id, name: s.name, content };
      } catch (err) {
        // One specialist failing shouldn't sink the whole reply.
        return { id: s.id, name: s.name, content: null, error: err.message };
      }
    })
  );

  return results.filter((r) => r.content);
}

export async function synthesize(message, notes, history) {
  const notesBlock = notes.length
    ? notes.map((n) => `[${n.name} notes]\n${n.content}`).join('\n\n')
    : '[No specialist notes this time — answer directly and well.]';

  const context = withContext(message, history);
  const userMessage = `${context}\n\nSpecialist notes:\n${notesBlock}\n\nWrite the final reply now.`;

  return callMuse({
    systemPrompt: ROUTER_SYNTH_PROMPT,
    userMessage,
    reasoningEffort: 'medium',
    maxTokens: 700
  });
}
