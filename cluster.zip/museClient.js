// Thin wrapper around Meta's Model API (Muse Spark models).
// Docs: https://ai.developer.meta.com/docs/  Base: https://api.meta.ai/v1
// Auth: Authorization: Bearer <META_API_KEY>. Chat Completions endpoint is
// OpenAI-compatible, which is why this reads like a standard chat call.

const BASE_URL = process.env.MUSE_API_BASE || 'https://api.meta.ai/v1';
const MODEL = process.env.MUSE_MODEL_ID || 'muse-spark-1.2';

/**
 * Calls one Muse Spark agent with a system prompt + a single user turn.
 * @param {Object} opts
 * @param {string} opts.systemPrompt - the agent's persona/instructions
 * @param {string} opts.userMessage - the content for this turn
 * @param {string} [opts.reasoningEffort] - "minimal" | "low" | "medium" | "high" | "xhigh"
 * @param {number} [opts.maxTokens]
 * @returns {Promise<string>} the model's text reply
 */
export async function callMuse({ systemPrompt, userMessage, reasoningEffort = 'medium', maxTokens = 500 }) {
  const apiKey = process.env.META_API_KEY;
  if (!apiKey) {
    throw new Error('META_API_KEY is not set. Add it to your .env or host environment variables.');
  }

  const res = await fetch(`${BASE_URL}/chat/completions`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${apiKey}`
    },
    body: JSON.stringify({
      model: MODEL,
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: userMessage }
      ],
      reasoning_effort: reasoningEffort,
      max_tokens: maxTokens
    })
  });

  if (!res.ok) {
    const detail = await res.text().catch(() => '');
    throw new Error(`Meta Model API returned ${res.status}: ${detail.slice(0, 300)}`);
  }

  const data = await res.json();
  const content = data?.choices?.[0]?.message?.content;
  if (typeof content !== 'string') {
    throw new Error('Meta Model API returned an unexpected response shape.');
  }
  return content;
}
