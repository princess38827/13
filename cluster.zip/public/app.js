const nodesEl = document.getElementById('nodes');
const statusEl = document.getElementById('status');
const chatEl = document.getElementById('chat');
const emptyStateEl = document.getElementById('emptyState');
const formEl = document.getElementById('composer');
const inputEl = document.getElementById('input');
const sendBtn = document.getElementById('sendBtn');
const agentCountEl = document.getElementById('agentCount');

let agents = [];
let history = [];
let fadeTimer = null;

async function loadAgents() {
  try {
    const res = await fetch('/api/agents');
    const data = await res.json();
    agents = data.agents || [];
    agentCountEl.textContent = `${agents.length} agents ready`;
  } catch {
    agents = [];
  }
  renderNodes([]);
}

function idsToNames(ids) {
  return ids.map((id) => agents.find((a) => a.id === id)?.name || id).join(', ');
}

function renderNodes(activeIds) {
  nodesEl.innerHTML = '';
  agents.forEach((a) => {
    const dot = document.createElement('div');
    dot.className = 'node' + (activeIds.includes(a.id) ? ' active' : '');
    dot.title = a.name;
    nodesEl.appendChild(dot);
  });
}

function addMessage(role, text) {
  emptyStateEl.style.display = 'none';
  const div = document.createElement('div');
  div.className = 'msg ' + role;
  div.textContent = text;
  chatEl.appendChild(div);
  chatEl.scrollTop = chatEl.scrollHeight;
  return div;
}

function addThinkingBubble() {
  emptyStateEl.style.display = 'none';
  const div = document.createElement('div');
  div.className = 'msg assistant thinking';
  div.innerHTML = '<span class="dot"></span><span class="dot"></span><span class="dot"></span>';
  chatEl.appendChild(div);
  chatEl.scrollTop = chatEl.scrollHeight;
  return div;
}

function setStatus(text) {
  statusEl.textContent = text;
}

formEl.addEventListener('submit', async (e) => {
  e.preventDefault();
  const text = inputEl.value.trim();
  if (!text) return;

  if (fadeTimer) clearTimeout(fadeTimer);
  inputEl.value = '';
  sendBtn.disabled = true;
  addMessage('user', text);

  const routerId = agents.find((a) => a.id === 'router')?.id;
  renderNodes(routerId ? [routerId] : []);
  setStatus('Routing your message…');
  const thinkingBubble = addThinkingBubble();

  try {
    const res = await fetch('/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message: text, history })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Unknown error');

    thinkingBubble.remove();
    const consulted = data.consulted || [];
    renderNodes(routerId ? [...consulted, routerId] : consulted);
    setStatus(consulted.length ? `Consulted: ${idsToNames(consulted)}` : 'Answered directly');
    addMessage('assistant', data.reply);

    history.push({ role: 'user', content: text });
    history.push({ role: 'assistant', content: data.reply });

    fadeTimer = setTimeout(() => {
      renderNodes([]);
      setStatus('Idle');
    }, 4000);
  } catch (err) {
    thinkingBubble.remove();
    addMessage('error', 'The cluster hit a snag: ' + err.message);
    setStatus('Idle');
    renderNodes([]);
  } finally {
    sendBtn.disabled = false;
    inputEl.focus();
  }
});

loadAgents();
