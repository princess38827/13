import 'dotenv/config';
import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { ROUTER_ID, ROUTER_NAME, SPECIALISTS } from './agents.js';
import { routeMessage, consultSpecialists, synthesize } from './orchestrator.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();

// Needed so the rate limiter below sees the real client IP behind a host's proxy.
app.set('trust proxy', 1);
app.use(express.json({ limit: '100kb' }));
app.use(express.static(path.join(__dirname, 'public')));

// A basic guard against a runaway API bill if this ever goes public —
// not real abuse protection. See README before sharing the link widely.
const hits = new Map();
function rateLimit(req, res, next) {
  const ip = req.ip || 'unknown';
  const now = Date.now();
  const windowMs = 60_000;
  const max = 20;
  const recent = (hits.get(ip) || []).filter((t) => now - t < windowMs);
  recent.push(now);
  hits.set(ip, recent);
  if (recent.length > max) {
    return res.status(429).json({ error: 'Too many messages — wait a moment and try again.' });
  }
  next();
}

app.get('/api/agents', (_req, res) => {
  res.json({
    agents: [{ id: ROUTER_ID, name: ROUTER_NAME }, ...SPECIALISTS.map((s) => ({ id: s.id, name: s.name }))]
  });
});

app.get('/api/health', (_req, res) => {
  res.json({ status: 'ok', hasKey: Boolean(process.env.META_API_KEY) });
});

app.post('/api/chat', rateLimit, async (req, res) => {
  const { message, history } = req.body || {};
  if (typeof message !== 'string' || !message.trim()) {
    return res.status(400).json({ error: 'message is required' });
  }

  try {
    const { consult } = await routeMessage(message);
    const notes = await consultSpecialists(consult, message, history);
    const reply = await synthesize(message, notes, history);
    res.json({ reply, consulted: notes.map((n) => n.id) });
  } catch (err) {
    console.error('Cluster error:', err);
    res.status(500).json({ error: err.message || 'The cluster hit a snag reaching Meta Model API.' });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Cluster is running at http://localhost:${PORT}`);
  if (!process.env.META_API_KEY) {
    console.warn('Warning: META_API_KEY is not set — chat requests will fail until you add it.');
  }
});
